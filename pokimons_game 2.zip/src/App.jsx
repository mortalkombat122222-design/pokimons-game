
import React, { useEffect, useState, useRef, createContext, useContext } from "react";

/*
  Pokimons — Starter
  NOTE: This is a starter project. It uses original placeholder art and data.
  It intentionally avoids Nintendo-owned assets. Data for Gen-VI species (names/stats)
  are included as JSON in /data. Replace art and audio with your own assets for final polish.
*/

// Utilities
const uuid = () => Math.random().toString(36).slice(2, 9);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const chance = (n,d)=> Math.random() < n/d;

// Constants
const SHINY_CHANCE = 1/4500;
const LEGENDARY_RATE = 1/12000;

const sampleMove = { id: "tackle", name: "Tackle", power: 40, accuracy: 100, type: "normal", category: "physical" };

// Minimal placeholder Pokedex (data/gen6_sample_pokimons.json contains more)
const POKEDEX = [
  { id: "chespin", name: "Chespin", baseStats:{hp:56,atk:61,def:65,spAtk:48,spDef:45,spd:38}, types:["grass"], moves:["tackle","vine_whip"], rarity:"common" },
  { id: "delphox", name: "Delphox", baseStats:{hp:75,atk:69,def:72,spAtk:114,spDef:100,spd:104}, types:["fire","psychic"], moves:["psyshock","fire_blast"], rarity:"rare" }
];

const MOVES = {
  tackle: sampleMove,
  vine_whip: { id:"vine_whip", name:"Vine Whip", power:45, accuracy:100, type:"grass", category:"physical" },
  psyshock: { id:"psyshock", name:"Psyshock", power:80, accuracy:100, type:"psychic", category:"special" },
  fire_blast: { id:"fire_blast", name:"Fire Blast", power:110, accuracy:85, type:"fire", category:"special" }
};

// Save
const SAVE_KEY = "pokimons_save_v1";
const saveToLocal = (data)=>{ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(data)); }catch(e){console.error(e);} };
const loadFromLocal = ()=>{ try{ const r=localStorage.getItem(SAVE_KEY); return r?JSON.parse(r):null;}catch(e){return null;} };

// AudioManager (placeholder)
class AudioManager { constructor(){ this.ctx=null; this.music=null;} async init(){ if(!this.ctx) this.ctx=new (window.AudioContext||window.webkitAudioContext)(); } stopMusic(){ if(this.music){ try{ this.music.stop(); }catch(e){} this.music=null; } } }
const audio = new AudioManager();

// Game Context
const GameContext = createContext(null);
const useGame = ()=> useContext(GameContext);

const makeWildEncounter = (areaRarity="common")=>{
  const pool = POKEDEX.filter(p=>p.rarity===areaRarity||areaRarity==="any");
  const isLegendary = chance(1, Math.round(1/LEGENDARY_RATE));
  let pick = isLegendary ? (POKEDEX.find(p=>p.rarity==="legendary")||pool[Math.floor(Math.random()*pool.length)]) : pool[Math.floor(Math.random()*pool.length)];
  const shiny = chance(1, Math.round(1/SHINY_CHANCE));
  return { id:uuid(), speciesId: pick.id, name: pick.name, lv: Math.max(1, Math.floor(Math.random()*10)+3), stats:{...pick.baseStats}, types: pick.types, moves: pick.moves.map(m=>MOVES[m]).filter(Boolean), shiny, legendary: pick.rarity==="legendary" };
};

const calcDamageFull = (attacker, defender, move)=>{
  const LV = attacker.lv || 50;
  const power = move.power || 40;
  const A = move.category==='special'? attacker.spAtk : attacker.atk;
  const D = move.category==='special'? defender.spDef : defender.def;
  const base = Math.floor(((2*LV)/5 + 2) * power * (A/D) /50 ) + 2;
  const stab = (attacker.types || []).includes(move.type)?1.5:1;
  const rand = 0.85 + Math.random()*0.15;
  return Math.max(1, Math.floor(base * stab * rand));
};

// Core component
export default function App(){
  const [player, setPlayer] = useState(()=> loadFromLocal()?.player || defaultPlayer());
  const [party, setParty] = useState(()=> loadFromLocal()?.party || defaultStarterParty(player));
  const [scene, setScene] = useState(()=> loadFromLocal()?.scene || "overworld");
  const [log, setLog] = useState([]);
  const [currentEncounter, setCurrentEncounter] = useState(null);
  const [inBattle, setInBattle] = useState(false);
  const saveTimer = useRef(null);

  useEffect(()=>{
    const payload = { player, party, scene };
    if(saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(()=> saveToLocal(payload), 8000);
    return ()=> clearTimeout(saveTimer.current);
  }, [player, party, scene]);

  const walkStep = (area="any")=>{
    if(Math.random()<0.12){
      const enc = makeWildEncounter(area);
      setCurrentEncounter(enc);
      setInBattle(true);
      pushLog(`A wild ${enc.name}${enc.shiny?" ✨":""} appeared!`);
    }
  };

  const pushLog = (t)=> setLog(l=>[...l.slice(-80), `[${new Date().toLocaleTimeString()}] ${t}`]);

  const battleStepPlayerAttack = ()=>{
    if(!currentEncounter || party.length===0) return;
    const playerMon = party[0];
    const move = MOVES[playerMon.moves[0]] || sampleMove;
    const dmg = calcDamageFull(playerMon, currentEncounter, move);
    pushLog(`${playerMon.name} used ${move.name}! It dealt ${dmg} damage.`);
    currentEncounter.hp = (currentEncounter.hp || currentEncounter.stats.hp) - dmg;
    if(currentEncounter.hp <= 0){
      pushLog(`Wild ${currentEncounter.name} fainted!`);
      setInBattle(false); setCurrentEncounter(null);
    } else {
      const wildMove = currentEncounter.moves[0] || sampleMove;
      const dmg2 = calcDamageFull(currentEncounter, playerMon, wildMove);
      pushLog(`Wild ${currentEncounter.name} used ${wildMove.name}! It dealt ${dmg2} damage.`);
      playerMon.hp = (playerMon.hp || playerMon.stats.hp) - dmg2;
      setParty([...party]);
      if(playerMon.hp <= 0) pushLog(`${playerMon.name} fainted!`);
    }
  };

  useEffect(()=> { pushLog("Game ready — autosave enabled."); }, []);

  const exportSave = ()=>{
    const data = { player, party, scene };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `pokimons_save_${new Date().toISOString()}.json`; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <GameContext.Provider value={{ player, setPlayer, party, setParty, pushLog }}>
      <div className="container">
        <header style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
          <h1>Pokimons — Starter</h1>
          <div style={{display:"flex", gap:8}}>
            <button className="btn" onClick={()=>walkStep("any")}>Walk</button>
            <button className="btn" onClick={battleStepPlayerAttack} disabled={!inBattle}>Attack</button>
            <button className="btn" onClick={exportSave}>Export Save</button>
          </div>
        </header>

        <main style={{marginTop:16}}>
          <section style={{display:"flex", gap:16}}>
            <div style={{flex:2, background:"#0f1724", padding:12, borderRadius:12}}>
              <div style={{height:320, background:"linear-gradient(180deg,#0b1220,#071026)", borderRadius:8, padding:12}}>
                <p>Overworld area — replace with high-res art and WebGL/PIXI rendering for crisp visuals.</p>
                <p style={{opacity:0.8}}>Tip: Use spine-skeletal animations for characters and PIXI for particle FX.</p>
              </div>
            </div>

            <aside style={{flex:1}}>
              <div style={{background:"#0f1724", padding:12, borderRadius:12}}>
                <h3>Player</h3>
                <p>Name: {player.name}</p>
                <p>Money: ${player.money}</p>
                <p>Location: {scene}</p>
                <div style={{marginTop:8}}>
                  <h4>Party</h4>
                  <ul>
                    {party.map((p,i)=> <li key={i}>{p.name} Lv{p.lv} {p.shiny?"✨":""}</li>)}
                  </ul>
                </div>
                <div style={{marginTop:8}}>
                  <button className="btn" onClick={()=>{ setScene("town"); pushLog("Traveled to town."); }}>Go to Town</button>
                  <button className="btn" style={{marginTop:8}} onClick={()=>{ setScene("overworld"); pushLog("Returned to overworld."); }}>Back</button>
                </div>
              </div>
            </aside>
          </section>

          <section style={{display:"flex", gap:16, marginTop:12}}>
            <div style={{flex:1, background:"#0f1724", padding:12, borderRadius:12}}>
              <h4>Log</h4>
              <div style={{maxHeight:160, overflow:"auto"}}>{log.slice().reverse().map((l,i)=><div key={i} style={{opacity:0.9}}>{l}</div>)}</div>
            </div>
            <div style={{flex:1, background:"#0f1724", padding:12, borderRadius:12}}>
              <h4>Dialogues</h4>
              <DialogueInput onSend={(t)=>{ pushLog(`${player.name}: ${t}`); }} />
            </div>
          </section>
        </main>
      </div>
    </GameContext.Provider>
  );
}

// Helper components
function DialogueInput({ onSend }){
  const [text,setText]=useState("");
  return (<div><input value={text} onChange={e=>setText(e.target.value)} placeholder="Say something..." style={{width:"100%",padding:8,background:"#071026",borderRadius:6}} /> <div style={{marginTop:8}}><button className="btn" onClick={()=>{ if(text.trim()){ onSend(text.trim()); setText(""); } }}>Send</button></div></div>);
}

// Defaults
function defaultPlayer(){ return { id: uuid(), name: "Player", gender: "male", money: 500, relationship: {} }; }
function defaultStarterParty(player){ const starter = POKEDEX[0]; return [{ id: uuid(), speciesId: starter.id, name: starter.name, lv:5, stats: starter.baseStats, hp: starter.baseStats.hp, moves: starter.moves, types: starter.types, shiny:false }]; }
