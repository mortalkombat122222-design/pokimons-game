# Pokimons — Starter Project

This is a starter Vite + React project for the **Pokimons** web game (Pokimons is a fan-original brand name; this project does NOT include Nintendo-owned artwork or audio).

## Quick start (local)
1. Install dependencies:
   ```
   npm install
   ```
2. Start dev server:
   ```
   npm run dev
   ```
   Open the printed URL (localhost) on your laptop, or access it from your iPad via your laptop's local IP.

## Build & deploy
- To build:
  ```
  npm run build
  ```
- To preview the production build locally:
  ```
  npm run preview
  ```

## iPad play (simple)
- Host the built `dist` on a static host (Netlify / Vercel) or run a local server on your laptop and open the IP URL in Safari on the iPad.
- Controls are touch-friendly. Autosave uses localStorage; you can export saves via the in-game Export Save button.

## Notes
- This is a starter template. Replace placeholder art and audio with your original assets.
- The `data/gen6_sample_pokimons.json` contains sample Gen-VI data entries for testing.
